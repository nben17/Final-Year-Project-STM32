/*
 * ADF4351_SPI.h
 *
 *  Created on: Oct 4, 2021
 *      Author: JerryBenny
 */

#ifndef SRC_ADF4351_SPI_H_
	//Include the SPI function header if not defined
	#define SRC_ADF4351_SPI_H_

	//Dependencies
	#include "math.h"
	#include "stm32f4xx_hal.h"

	//Definitions
	#define ADF4351_RFA_LTC5586 0
	#define ADF4351_RFB_ADL5375 1

	#define ADF4351_NEGFOUR_DBM_POWER 0
	#define ADF4351_NEGONE_DBM_POWER 1
	#define ADF4351_POSTWO_DBM_POWER 2
	#define ADF4351_POSFIVE_DBM_POWER 3

	#define ADF4351_TOTAL_REG_NUM 6
	#define ADF4351_REGISTER_0 0
	#define ADF4351_REGISTER_1 1
	#define ADF4351_REGISTER_2 2
	#define ADF4351_REGISTER_3 3
	#define ADF4351_REGISTER_4 4
	#define ADF4351_REGISTER_5 5

	//Register 0 default values and shifts
	#define ADF4351_INT_VALUE_DEFAULT 433 //The default values for the INT, FRAC and MOD values are intended to allow the device to default to 433.92 MHz operation
	#define ADF4351_INT_VALUE_SHIFT 15
	#define ADF4351_FRAC_VALUE_DEFAULT 3680 //3680
	#define ADF4351_FRAC_VALUE_SHIFT 3

	//Register 1 default values and shifts
	#define ADF4351_PHASE_ADJUST_BIT_DEFAULT 0 //Leaving the phase adjust bit to 0 enables part to automatically reselect which VCO it uses based on the frequency it needs to run at, and resync phase
	#define ADF4351_PHASE_ADJUST_BIT_SHIFT 28
	#define ADF4351_PRESCALER_BIT_DEFAULT 0 //Default prescaler is the 4/5 prescaler (as opposed to 8/9 prescaler). This allows ADF4351 to operate up to 3.6 GHz. If higher frequency needed, switch to 8/9 prescaler.
	#define ADF4351_PRESCALER_BIT_SHIFT 27
	#define ADF4351_PHASE_VALUE_DEFAULT 1000 //Should be less than the modulus value. The RF output phase will be equal to 360*(PHASE/MOD), so PHASE < MOD. Since a fixed phase is not required, we can adjust the phase to optimise spur noise by creating a lookup table.
	#define ADF4351_PHASE_VALUE_SHIFT 15
	#define ADF4351_MODULUS_VALUE_DEFAULT 4000
	#define ADF4351_MODULUS_VALUE_SHIFT 3

	//Register 2 default values and shifts
	#define ADF4351_LOWNOISE_SPUR_BITS_DEFAULT 3 //Default set to 3 (0xb11) for low spur mode, can be changed to 0 (0xb00) for low phase noise mode. Values 1 (0xb01) and 2 (0xb10) are reserved (NOT ALLOWED).
	#define ADF4351_LOWNOISE_SPUR_BITS_SHIFT 29
	#define ADF4351_MUXOUT_DEFAULT 6 //A value of 6 here (0xb110) sets the MUXOUT pin to have the state of the digital lock detect. We can change this if required (refer to ADF4351 datasheet)
	#define ADF4351_MUXOUT_SHIFT 26
	#define ADF4351_REFDOUBLER_BIT_DEFAULT 0 //We disable the reference doubler. This is assumed for our calculations for INT, FRAC, MOD etc. DO NOT CHANGE, unless you've spoken to Nidhin Benny or understand the consequences of changing this bit.
	#define ADF4351_REFDOUBLER_BIT_SHIFT 25
	#define ADF4351_RDIV2_BIT_DEFAULT 0 //Disables the reference divide by 2 (
	#define ADF4351_RDIV2_BIT_SHIFT 24
	#define ADF4351_RCOUNTER_DEFAULT 25 //With the R counter set to 25, and the reference doubler and divide by 2 bits both set to zero, we get a PFD frequency of 1 MHz, which is assumed for our calculations of INT, FRAC, MOD values etc
	#define ADF4351_RCOUNTER_SHIFT 14
	#define ADF4351_DOUBLEBUFFER_DEFAULT 1 //Setting this bit to 1 means that register 4 bits 22:20 (which set the RF output divider) are double buffered - i.e we need to write a value to register 4, then write to register 0 before register 4's values will take effect.
	#define ADF4351_DOUBLEBUFFER_SHIFT 13
	#define ADF4351_CHARGEPUMPCURRENT_DEFAULT 15 //Setting the charge pump currrent bits to 15 (0xb1111) sets the actual charge pump current to the maximum 5 mA.
	#define ADF4351_CHARGEPUMPCURRENT_SHIFT 9
	#define ADF4351_LDF_BIT_DEFAULT 0 //Determines the number of PFD cycles that the phase locked loop waits to detect locking. It is recommended in the datasheet that this bit be set to 0 for fractional N mode (as we are using here). This will lead to a higher 40 cycles of waiting as opposed to 5 when this bit is 1.
	#define ADF4351_LDF_BIT_SHIFT 8
	#define ADF4351_LDP_BIT_DEFAULT 0 //Determines the slip that the output is allowed to have to still be considered locked. If this bit is 0, then the output can be out of sync by 10 ns and is considered locked. If 1, the output can only be a max of 6 ns out of sync to be considered locked. For lock detect to go high, this condition must be met for the number of cycles specified by the LDF bit above (either 40 or 5 cycles).
	#define ADF4351_LDP_BIT_SHIFT 7
	#define ADF4351_PDPOL_DEFAULT 1 //Determines phase detector polarity - a value of 1 is to be used here if a passive non-inverting loop filter is used (as is our case). If an inverting filter of any type is used (active or passive), set to 0.
	#define ADF4351_PDPOL_SHIFT 6
	#define ADF4351_PWRDWN_BIT_DEFAULT 0 //Setting this bit to 1 performs a power down of the ADF4351. The registers still remain active and retain data (unless supply power is removed).
	#define ADF4351_PWRDWN_BIT_SHIFT 5
	#define ADF4351_CHARGEPUMPTHREESTATE_DEFAULT 0 //Setting this bit to 1 puts the charge pump in three-state mode. Leave as 0 during normal operation.
	#define ADF4351_CHARGEPUMPTHREESTATE_SHIFT 4
	#define ADF4351_COUNTERRESET_DEFAULT 0 //Setting this bit to 1 resets the R and N counters.
	#define ADF4351_COUNTERRESET_SHIFT 3

	//Register 3 default values and shifts
	#define ADF4351_BANDSELECTCLOCKMODE_BIT_DEFAULT 0 //Setting this bit to 0 selects a slower logic sequence for VCO band selection.
	#define ADF4351_BANDSELECTCLOCKMODE_BIT_SHIFT 23
	#define ADF4351_ABP_BIT_DEFAULT 0 //ABP being set to 0 is recommended for fractional-N applications
	#define ADF4351_ABP_BIT_SHIFT 22
	#define ADF4351_CHARGECANCEL_BIT_DEFAULT 0 //Setting this bit to 1 enables charge pump charge cancellation, reducing PFD spurs. However, for fractional-N mode, this cannot be used and must be set to 0.
	#define ADF4351_CHARGECANCEL_BIT_SHIFT 21
	#define ADF4351_CSR_BIT_DEFAULT 0 //We disable CSR by default, because enabling it requires us to activate the reference divide-by-2 bit, which changes our calculations for frequency etc.
	#define ADF4351_CSR_BIT_SHIFT 18
	#define ADF4351_CLKDIVMODE_DEFAULT 2 //Setting this to 2 (0xb10) activates phase resync.
	#define ADF4351_CLKDIVMODE_SHIFT 15
	#define ADF4351_CLOCKDIVIDERVAL_DEFAULT 250 //Setting this value to 250, with MOD value = 4000 gives us a t_sync time of 1 second, which is much higher than the worst case expected lock time (~10 ms).
	#define ADF4351_CLOCKDIVIDERVAL_SHIFT 3

	//Register 4 default values and shifts
	#define ADF4351_FEEDBACKSEL_BIT_DEFAULT 0 //Setting this bit to 0 includes the RF divider in the PLL feedback loop. This is critical, as the loop filter has been designed with this in mind.
	#define ADF4351_FEEDBACKSEL_BIT_SHIFT 23
	#define ADF4351_RFDIVIDERSEL_DEFAULT 3 //Setting the RF Divider
	#define ADF4351_RFDIVIDERSEL_SHIFT 20
	#define ADF4351_BANDSELCLOCKDIVIDERVAL_DEFAULT 4 //This value further divides the output of the R counter, and feeds the VCO band select logic.
	#define ADF4351_BANDSELCLOCKDIVIDERVAL_SHIFT 12
	#define ADF4351_VCOPWRDWN_BIT_DEFAULT 0 //Setting this bit to 0 powers the VCO up, 1 powers it down.
	#define ADF4351_VCOPWRDWN_BIT_SHIFT 11
	#define ADF4351_MTLD_BIT_DEFAULT 1 //Setting this bit to 1 ensures that the RF outputs remain muted until the part senses that the phase locked loop has been locked. If 0, the RF outputs do not wait for lock to happen.
	#define ADF4351_MTLD_BIT_SHIFT 10
	#define ADF4351_AUXOUTSEL_BIT_DEFAULT 0 //Setting this bit to 0 ensures that the auxilliary RF output - RFB+/- (which we want to have same signal as normal RF output) is taken from the output of the RF dividers. Setting to 1 will cause the aux output to be taken from the VCO directly.
	#define ADF4351_AUXOUTSEL_BIT_SHIFT 9
	#define ADF4351_AUXOUTEN_BIT_DEFAULT 1 //Setting this bit to 1 ensures that the auxilliary RF output is enabled. Auxilliary output supplies the ADL5375 transmitter.
	#define ADF4351_AUXOUTEN_BIT_SHIFT 8
	#define ADF4351_AUXOUTPWR_DEFAULT 3 //Setting these bits to 3 (0xb11) gives output power of 5 dBm. This can be adjusted later.
	#define ADF4351_AUXOUTPWR_SHIFT 6
	#define ADF4351_RFOUTEN_BIT_DEFAULT 1 //Setting this bit to 1 ensures that the normal RF output - RFA+/- is enabled. Normal output supplies LTC5586 receiver.
	#define ADF4351_RFOUTEN_BIT_SHIFT 5
	#define ADF4351_OUTPWR_DEFAULT 3 //Setting these bits to 3 (0xb11) gives output power of 5 dBm. This can be adjusted later.
	#define ADF4351_OUTPWR_SHIFT 3

	//Register 5 default values and shifts
	#define ADF4351_LDPINMODE_DEFAULT 1 //Sets the lock detect pin function to digital lock detect. We can change this to be permanently low or permanently high.
	#define ADF4351_LDPINMODE_SHIFT 22
	#define ADF4351_REG5_RESERVED_ONES_DEFAULT 3
	#define ADF4351_REG5_RESERVED_ONES_SHIFT 19

	//Variables
	uint32_t txBufSPI_ADF4351[6];

	//Function Declarations
	void initialiseADF4351(void);
	void initialiseADF4351SPI(void);
	void ADF4351_Write(uint8_t addr, uint8_t totalBytesToWrite, uint32_t * txBuf);
	void ADF4351_HardPwrDwn(void);
	void ADF4351_HardPwrUp(void);
	void ADF4351_SoftPwrDwn(uint32_t * txBuf);
	void ADF4351_SoftPwrUp(uint32_t * txBuf);
	void ADF4351_RFOutputsHardEnableBoth(void);
	void ADF4351_RFOutputsHardDisableBoth(void);
	uint8_t ADF4351_RFOutputSoftEnable(uint8_t output, uint32_t * txBuf);
	uint8_t ADF4351_RFOutputSoftDisable(uint8_t output, uint32_t * txBuf);
	uint8_t ADF4351_RFOutputSoftSetPwr(uint8_t output, uint8_t power, uint32_t * txBuf);
	uint8_t ADF4351_ChangeFrequency(float freq);

#endif /* SRC_ADF4351_SPI_H_ */
