/*
 * ADF4351_SPI.c
 *
 *  Created on: Oct 4, 2021
 *      Author: JerryBenny
 */

#include "math.h"
#include "stm32f4xx_hal.h"
#include "ADF4351_SPI.h"
#include "main.h"

//This function inititalises the ADF4351 by first using the ADF4351_HardPwrUp and ADF4351_RFOutputsHardEnableBoth functions.
//It then initialises the buffer which stores all the default values for the ADF4351 and writes the SPI registers of the ADF4351 according to what is currently in the buffer.
void initialiseADF4351(void){
	ADF4351_HardPwrUp();
	ADF4351_RFOutputsHardEnableBoth();
	initialiseADF4351SPI();
}

//This function initialises all the ADF4351 registers to the default values described in the ADF4351.h header file.
void initialiseADF4351SPI(void){
	uint8_t counter = 0; //Counter to cycle through all the registers and set them to zero, before initialising.
	while (counter < ADF4351_TOTAL_REG_NUM){
		txBufSPI_ADF4351[counter] = 0; //Clear the transmit buffer for the ADF4351
		counter++;
	}

	//The below statements transfer the values defined as defaults into the register buffer, but does not actually write it to the register itself.
	txBufSPI_ADF4351[ADF4351_REGISTER_0] = ADF4351_INT_VALUE_DEFAULT << ADF4351_INT_VALUE_SHIFT | ADF4351_FRAC_VALUE_DEFAULT << ADF4351_FRAC_VALUE_SHIFT | ADF4351_REGISTER_0;
	txBufSPI_ADF4351[ADF4351_REGISTER_1] = ADF4351_PHASE_ADJUST_BIT_DEFAULT << ADF4351_PHASE_ADJUST_BIT_SHIFT | ADF4351_PRESCALER_BIT_DEFAULT << ADF4351_PRESCALER_BIT_SHIFT | ADF4351_PHASE_VALUE_DEFAULT << ADF4351_PHASE_VALUE_SHIFT | ADF4351_MODULUS_VALUE_DEFAULT << ADF4351_MODULUS_VALUE_SHIFT | ADF4351_REGISTER_1;
	txBufSPI_ADF4351[ADF4351_REGISTER_2] = ADF4351_LOWNOISE_SPUR_BITS_DEFAULT<< ADF4351_LOWNOISE_SPUR_BITS_SHIFT | ADF4351_MUXOUT_DEFAULT << ADF4351_MUXOUT_SHIFT | ADF4351_REFDOUBLER_BIT_DEFAULT << ADF4351_REFDOUBLER_BIT_SHIFT | ADF4351_RDIV2_BIT_DEFAULT << ADF4351_RDIV2_BIT_SHIFT | ADF4351_RCOUNTER_DEFAULT << ADF4351_RCOUNTER_SHIFT | ADF4351_DOUBLEBUFFER_DEFAULT << ADF4351_DOUBLEBUFFER_SHIFT | ADF4351_CHARGEPUMPCURRENT_DEFAULT << ADF4351_CHARGEPUMPCURRENT_SHIFT | ADF4351_LDF_BIT_DEFAULT << ADF4351_LDF_BIT_SHIFT | ADF4351_LDP_BIT_DEFAULT << ADF4351_LDP_BIT_SHIFT | ADF4351_PDPOL_DEFAULT << ADF4351_PDPOL_SHIFT | ADF4351_PWRDWN_BIT_DEFAULT << ADF4351_PWRDWN_BIT_SHIFT | ADF4351_CHARGEPUMPTHREESTATE_DEFAULT << ADF4351_CHARGEPUMPTHREESTATE_SHIFT | ADF4351_COUNTERRESET_DEFAULT << ADF4351_COUNTERRESET_SHIFT | ADF4351_REGISTER_2;
	txBufSPI_ADF4351[ADF4351_REGISTER_3] = ADF4351_BANDSELECTCLOCKMODE_BIT_DEFAULT << ADF4351_BANDSELECTCLOCKMODE_BIT_SHIFT | ADF4351_ABP_BIT_DEFAULT << ADF4351_ABP_BIT_SHIFT | ADF4351_CHARGECANCEL_BIT_DEFAULT << ADF4351_CHARGECANCEL_BIT_SHIFT | ADF4351_CSR_BIT_DEFAULT << ADF4351_CSR_BIT_SHIFT | ADF4351_CLKDIVMODE_DEFAULT << ADF4351_CLKDIVMODE_SHIFT | ADF4351_CLOCKDIVIDERVAL_DEFAULT << ADF4351_CLOCKDIVIDERVAL_SHIFT | ADF4351_REGISTER_3;
	txBufSPI_ADF4351[ADF4351_REGISTER_4] = ADF4351_FEEDBACKSEL_BIT_DEFAULT << ADF4351_FEEDBACKSEL_BIT_SHIFT | ADF4351_RFDIVIDERSEL_DEFAULT << ADF4351_RFDIVIDERSEL_SHIFT | ADF4351_BANDSELCLOCKDIVIDERVAL_DEFAULT << ADF4351_BANDSELCLOCKDIVIDERVAL_SHIFT | ADF4351_VCOPWRDWN_BIT_DEFAULT << ADF4351_VCOPWRDWN_BIT_SHIFT | ADF4351_MTLD_BIT_DEFAULT << ADF4351_MTLD_BIT_SHIFT | ADF4351_AUXOUTSEL_BIT_DEFAULT << ADF4351_AUXOUTSEL_BIT_SHIFT | ADF4351_AUXOUTEN_BIT_DEFAULT << ADF4351_AUXOUTEN_BIT_SHIFT | ADF4351_AUXOUTPWR_DEFAULT << ADF4351_AUXOUTPWR_SHIFT | ADF4351_RFOUTEN_BIT_DEFAULT << ADF4351_RFOUTEN_BIT_SHIFT | ADF4351_OUTPWR_DEFAULT << ADF4351_OUTPWR_SHIFT | ADF4351_REGISTER_4;
	txBufSPI_ADF4351[ADF4351_REGISTER_5] = ADF4351_LDPINMODE_DEFAULT << ADF4351_LDPINMODE_SHIFT | ADF4351_REG5_RESERVED_ONES_DEFAULT << ADF4351_REG5_RESERVED_ONES_SHIFT | ADF4351_REGISTER_5;

	//The below statement transfer the now correctly initialised values in the txBufSPI_ADF4351 buffer to the ADF4351 registers
	ADF4351_Write(ADF4351_REGISTER_0, 1, txBufSPI_ADF4351);
	ADF4351_Write(ADF4351_REGISTER_1, 1, txBufSPI_ADF4351);
	ADF4351_Write(ADF4351_REGISTER_2, 1, txBufSPI_ADF4351);
	ADF4351_Write(ADF4351_REGISTER_3, 1, txBufSPI_ADF4351);
	ADF4351_Write(ADF4351_REGISTER_4, 1, txBufSPI_ADF4351);
	ADF4351_Write(ADF4351_REGISTER_5, 1, txBufSPI_ADF4351);
}


//Note that the ADF4351 has a simplex SPI-compatible inteface, which requires some modifcations:
//The data on the MOSI line is sampled into the shift register regardless of the state of the load enable (LE) line (which performs a somewhat equivalent function to CSB lines in traditional SPI architectures.
//A rising edge is required on the load enable line to load data from the shift register into the appropriate register.
//Also, some of the registers are double-buffered, meaning that, in order for the values placed in them to take effect, the user has to write to register 0 as well. The below function takes care of all of these differences.
void ADF4351_Write(uint8_t addr, uint8_t totalRegsToWrite, uint32_t * txBuf){
	uint8_t totalRegsWritten = 0; //Keeps track of how many registers have been written to.
	uint8_t regToWrite = addr; //Keeps track of which register is about to be written next.
	uint8_t bitToWrite = 31; //This bit keeps track of which bit is about to be written next. Since the ADF4351 (like LTC5586) takes bits MSB first, we start at 31.

	while (totalRegsWritten < totalRegsToWrite){
		bitToWrite = 31;
		//Pull the Load enable pin low, pull the clock pin low and pull the data pin low before starting communication
		HAL_GPIO_WritePin(ADF4351_LE_GPIO_Port,ADF4351_LE_Pin,GPIO_PIN_RESET);
		HAL_Delay(1);
		HAL_GPIO_WritePin(ADF4351_SCK_GPIO_Port,ADF4351_SCK_Pin,GPIO_PIN_RESET);
		HAL_Delay(1);
		HAL_GPIO_WritePin(ADF4351_MOSI_GPIO_Port,ADF4351_MOSI_Pin,GPIO_PIN_RESET);
		HAL_Delay(1);

		//In the for loop below, we rely on underflow of the variable bitToRead. As we subtract 1 from 0, it will give 255, breaking us out of the loop.
		while (bitToWrite < 32){
			HAL_GPIO_WritePin(ADF4351_SCK_GPIO_Port, ADF4351_SCK_Pin, GPIO_PIN_RESET);
			HAL_Delay(1);
			if ((txBuf[regToWrite] & (1 << bitToWrite)) != 0){
				//If the next bit to transmit is a 1, set the MOSI pin high
				HAL_GPIO_WritePin(ADF4351_MOSI_GPIO_Port, ADF4351_MOSI_Pin, GPIO_PIN_SET);
			}else{
				//If the next bit to transmit is a 0, set the MOSI pin low
				HAL_GPIO_WritePin(ADF4351_MOSI_GPIO_Port, ADF4351_MOSI_Pin, GPIO_PIN_RESET);
			}
			HAL_Delay(1);
			HAL_GPIO_WritePin(ADF4351_SCK_GPIO_Port, ADF4351_SCK_Pin, GPIO_PIN_SET);
			bitToWrite--;
			HAL_Delay(1);
		}
		//Reset the clock low again before proceeding to the finishing actions of the transaction
		HAL_GPIO_WritePin(ADF4351_SCK_GPIO_Port,ADF4351_SCK_Pin,GPIO_PIN_RESET);
		HAL_Delay(1);
		//Increments the register number which is about to be read
		regToWrite++;

		//If we are about to write the 7th register (which doesn't exist), then start from 0 again instead
		if (regToWrite > ADF4351_TOTAL_REG_NUM){
			regToWrite = 0;
		}

		//Incrementing the counter indicating the total number of registers that have been written to
		totalRegsWritten++;

		//Load the value in the shift register into the data register by setting LE high and then low (rising edge triggers data storage)
		HAL_GPIO_WritePin(ADF4351_LE_GPIO_Port,ADF4351_LE_Pin,GPIO_PIN_SET);
		HAL_Delay(1);
		HAL_GPIO_WritePin(ADF4351_LE_GPIO_Port,ADF4351_LE_Pin,GPIO_PIN_RESET);
		HAL_Delay(1);
		HAL_GPIO_WritePin(ADF4351_MOSI_GPIO_Port,ADF4351_MOSI_Pin,GPIO_PIN_RESET);
		HAL_Delay(1);
	}

	//Some of the registers (and subsections of other registers) in the ADF4351 are double-buffered. This means that, for the values written to those registers to take effect, we have to write a value to register 0.
	//The below section thus writes the current value of txBufSPI_ADF4351[0] to register 0 to finish the communication burst to the ADF4351.
	bitToWrite = 31;

	//In the for loop below, we rely on underflow of the variable bitToRead. As we subtract 1 from 0, it will give 255, breaking us out of the loop.
	while (bitToWrite < 32){
		HAL_GPIO_WritePin(ADF4351_SCK_GPIO_Port, ADF4351_SCK_Pin, GPIO_PIN_RESET);
		HAL_Delay(1);
		//tempWrite = txBuf[regToWrite] & (1 << bitToWrite);
		//HAL_GPIO_WritePin(ADF4351_MOSI_GPIO_Port, ADF4351_MOSI_Pin, tempWrite);
		if ((txBuf[ADF4351_REGISTER_0] & (1 << bitToWrite)) != 0){
			HAL_GPIO_WritePin(ADF4351_MOSI_GPIO_Port, ADF4351_MOSI_Pin, GPIO_PIN_SET);
		}else{
			HAL_GPIO_WritePin(ADF4351_MOSI_GPIO_Port, ADF4351_MOSI_Pin, GPIO_PIN_RESET);
		}
		//HAL_GPIO_WritePin(ADF4351_MOSI_GPIO_Port, ADF4351_MOSI_Pin, txBuf[ADF4351_REGISTER_0] & (1 << bitToWrite));
		HAL_Delay(1);
		HAL_GPIO_WritePin(ADF4351_SCK_GPIO_Port, ADF4351_SCK_Pin, GPIO_PIN_SET);
		bitToWrite--;
		HAL_Delay(1);
	}
	//Reset clock pin before proceeding
	HAL_GPIO_WritePin(ADF4351_SCK_GPIO_Port,ADF4351_SCK_Pin,GPIO_PIN_RESET);
	HAL_Delay(1);
	//Load the value in the shift reg into the data reg by setting LE high and then low (rising edge triggers data storage)
	HAL_GPIO_WritePin(ADF4351_LE_GPIO_Port,ADF4351_LE_Pin,GPIO_PIN_SET);
	HAL_Delay(1);
	HAL_GPIO_WritePin(ADF4351_LE_GPIO_Port,ADF4351_LE_Pin,GPIO_PIN_RESET);
	HAL_Delay(1);
	//Reset the communication lines to finish the transmission
	HAL_GPIO_WritePin(ADF4351_MOSI_GPIO_Port,ADF4351_MOSI_Pin,GPIO_PIN_RESET);
	HAL_Delay(1);
}

//Leave Phase adjust bit (REGISTER 1) as 0 - the part will perform automatic VCO band selection/phase resync when register 0 updated.
//Create lookup table for PHASE value optimisation across frequency (REGISTER 1)
//Low-noise/spur bits can be adjusted to optimise the part for either lower phase noise or lower spurs. Prefer lower spurs because of lack of filtering between ADF4351 and ADL5375

//ADF4351 is powered on only when the ADF4351_CE line is at logic high (3.3V). The below function writes the appropriate value to that pin to power up the ADF4351. Run this function when initialising the ADF4351.
void ADF4351_HardPwrDwn(void){
	//Pull the Chip Enable line low
	HAL_GPIO_WritePin(ADF4351_CE_GPIO_Port,ADF4351_CE_Pin,GPIO_PIN_RESET);
}

//This function does the opposite of the ADF4351_HardPwrDwn function, by setting the chip enable bit.
void ADF4351_HardPwrUp(void){
	//Pull the Chip Enable line high
	HAL_GPIO_WritePin(ADF4351_CE_GPIO_Port,ADF4351_CE_Pin,GPIO_PIN_SET);
}

//The function to set the ADF4351_RF_PwrDwn GPIO pin high. This function does not take arguments for which output to enable, because the one hardware line enables both the RFA and RFB outputs. To disable one or the other individually, use the software enable/disable functions.
void ADF4351_RFOutputsHardEnableBoth(void){
	HAL_GPIO_WritePin(ADF4351_RF_PwrDwn_GPIO_Port,ADF4351_RF_PwrDwn_Pin,GPIO_PIN_SET);
}

//The function to set the ADF4351_RF_PwrDwn GPIO pin low. This function does not take arguments for which output to disable, because the one hardware line disables both the RFA and RFB outputs. To enable one or the other individually, use the software enable/disable functions.
void ADF4351_RFOutputsHardDisableBoth(void){
	HAL_GPIO_WritePin(ADF4351_RF_PwrDwn_GPIO_Port,ADF4351_RF_PwrDwn_Pin,GPIO_PIN_RESET);
}

void ADF4351_SoftPwrDwn(uint32_t * txBuf){
	//Update the transmit buffer with the appropriate data to reflect the state of the disabled ADF4351 chip
	txBuf[ADF4351_REGISTER_2] |= 1 << ADF4351_PWRDWN_BIT_SHIFT;
	//Power down the ADF4351 chip (except for the registers) by writing a 1 to bit number 5 in register number 2
	ADF4351_Write(ADF4351_REGISTER_2, 1, txBufSPI_ADF4351);
}

void ADF4351_SoftPwrUp(uint32_t * txBuf){
	//Update the transmit buffer with the appropriate data to reflect the state of the enabled ADF4351 chip
	txBuf[ADF4351_REGISTER_2] &= ~(1 << ADF4351_PWRDWN_BIT_SHIFT);
	//Power up the ADF4351 chip by writing a 0 to bit number 5 in register number 2
	ADF4351_Write(ADF4351_REGISTER_2, 1, txBufSPI_ADF4351);
	//Set all the registers to current values found in the txBuffer
	ADF4351_Write(ADF4351_REGISTER_0, ADF4351_TOTAL_REG_NUM, txBufSPI_ADF4351);
}

uint8_t ADF4351_RFOutputSoftEnable(uint8_t output, uint32_t * txBuf){
	//Status variable to flag an error - set to 0 if error
	uint8_t ok = 1;

	//Takes 0 for RFA and 1 for RFB
	//Enables that RF output by writing a 1 to appropriate spot in the register
	if (output == ADF4351_RFA_LTC5586){
		txBuf[ADF4351_REGISTER_4] |= 1 << ADF4351_RFOUTEN_BIT_SHIFT;
		ADF4351_Write(ADF4351_REGISTER_4,1,txBufSPI_ADF4351);
	}else if (output == ADF4351_RFB_ADL5375){
		txBuf[ADF4351_REGISTER_4] |= 1 << ADF4351_AUXOUTEN_BIT_SHIFT;
		ADF4351_Write(ADF4351_REGISTER_4,1,txBufSPI_ADF4351);
	}else{
		//Status variable to flag an error - if user asks for an output other than RFA or RFB to be enabled, flag this
		ok = 0;
	}
	return ok;
}

uint8_t ADF4351_RFOutputSoftDisable(uint8_t output, uint32_t * txBuf){
	//Status variable to flag an error - set to 0 if error
	uint8_t ok = 1;

	//Takes 0 for RFA and 1 for RFB
	//Disables that RF output by writing a 0 to appropriate spot in the register
	if (output == ADF4351_RFA_LTC5586){
		txBuf[ADF4351_REGISTER_4] &= ~(1 << ADF4351_RFOUTEN_BIT_SHIFT);
		ADF4351_Write(ADF4351_REGISTER_4,1,txBufSPI_ADF4351);
	}else if (output == ADF4351_RFB_ADL5375){
		txBuf[ADF4351_REGISTER_4] &= ~(1 << ADF4351_AUXOUTEN_BIT_SHIFT);
		ADF4351_Write(ADF4351_REGISTER_4,1,txBufSPI_ADF4351);
	}else{
		//Status variable to flag an error - if user asks for an output other than RFA or RFB to be enabled, flag this
		ok = 0;
	}
	return ok;
}

uint8_t ADF4351_RFOutputSoftSetPwr(uint8_t output, uint8_t power, uint32_t * txBuf){
	//Takes the number of the RF output on the ADF4351 and the power to drive it at
	//Then sets the ADF4351 register 4 bits appropriately to drive the output at that power
	//Note that the output should be enabled separately usingthe ADF4351_RFOutputEnable() function
	uint8_t ok = 1;

	//Takes 0 for RFA and 1 for RFB
	//Disables that RF output by writing a 0 to appropriate spot in the register
	if ((output == ADF4351_RFA_LTC5586) & ((power == ADF4351_NEGFOUR_DBM_POWER) | (power == ADF4351_NEGONE_DBM_POWER) | (power == ADF4351_POSTWO_DBM_POWER) | (power == ADF4351_POSFIVE_DBM_POWER))){
		txBuf[ADF4351_REGISTER_4] &= ~(3 << ADF4351_OUTPWR_SHIFT); //Writes 0s in the two bits that represent RFA output power
		txBuf[ADF4351_REGISTER_4] |= (power << ADF4351_OUTPWR_SHIFT); //Writes the new power value in the two bits that represent RFA output power
		ADF4351_Write(ADF4351_REGISTER_4,1,txBufSPI_ADF4351);
	}else if ((output == ADF4351_RFB_ADL5375) & ((power == ADF4351_NEGFOUR_DBM_POWER) | (power == ADF4351_NEGONE_DBM_POWER) | (power == ADF4351_POSTWO_DBM_POWER) | (power == ADF4351_POSFIVE_DBM_POWER))){
		txBuf[ADF4351_REGISTER_4] &= ~(3 << ADF4351_AUXOUTPWR_SHIFT); //Writes 0s in the two bits that represent RFB output power
		txBuf[ADF4351_REGISTER_4] |= (power << ADF4351_AUXOUTPWR_SHIFT); //Writes the new power value in the two bits that represent RFB output power
		ADF4351_Write(ADF4351_REGISTER_4,1,txBufSPI_ADF4351);
	}else{
	//Status variable to flag an error - if user asks for an output other than RFA or RFB to be enabled, flag this
		ok = 0;
	}
	return ok;
}

//This function takes in a floating point value that represents the frequency needed from the ADF4351 in MHz and attempts to set the registers of the ADF4351 to make it create that frequency.
//If the requested frequency cannot be achieved, a 1 is returned, else, a zero is returned.
uint8_t ADF4351_ChangeFrequency(float freq){
	//The status variable will be set to 1 if it is impossible to change to the frequency that the user has requested. It will be returned at the end of the function call.
	uint8_t status = 0;
	//INT_MIN represents the minimum value of the integer part of the frequency that the part can accept. Depending on what prescaler is used, this can be 23 or 75.
	uint8_t INT_MIN = 23;
	//Sets the MODULUS value of the ADF4351. A value of 4000 allows us to have a channel spacing of 250 MHz.
	uint32_t MODULUS = 4000;
	//Sets the integer part of the frequency. The part is to default to 433.92 MHz unless a different frequency is required.
	uint32_t freq_int_part = 433;
	//The prescaler variable represents the prescaler value that the ADF4351 uses to divide down the VCO output.
	uint32_t prescaler;
	//Sets the fractional part of the frequency. Since the part defaults to 433.92 MHz, the fractional part is set to 92.
	uint32_t freq_frac_part = 92;
	//Default RF divider value of 0 means RF divider = 1
	uint32_t rf_divider = 0;
	//If the frequency requested is outside the range that the ADF4351 can supply, return 1
	if ((freq < 40) || (freq > 4350)){
		status = 1;
	}else{
		if (freq < 3600){
			prescaler = 0;
			INT_MIN = 23;
			//Set the RF divider based on the frequency requested
			if ((freq >= 40) && (freq < 68.75)){
				rf_divider = 6; //Leads to division of VCO output by 2^6 = 64
			}else if ((freq >= 68.75) && (freq < 137.5)){
				rf_divider = 5; //Leads to division of VCO output by 2^5 = 32
			}else if ((freq >= 137.5) && (freq < 275)){
				rf_divider = 4; //Leads to division of VCO output by 2^4 = 16
			}else if ((freq >= 275) && (freq < 550)){
				rf_divider = 3; //Leads to division of VCO output by 2^3 = 8
			}else if ((freq >= 550) && (freq < 1100)){
				rf_divider = 2; //Leads to division of VCO output by 2^2 = 4
			}else if ((freq >= 1100) && (freq < 2200)){
				rf_divider = 1; //Leads to division of VCO output by 2^1 = 2
			}else if ((freq >= 2200) && (freq < 4400)){
				rf_divider = 0; //Leads to division of VCO output by 2^0 = 1
			}else{
				status = 1;
			}
		}else{
			prescaler = 1;
			INT_MIN = 75;
			rf_divider = 0; //Leads to division of VCO output by 2^0 = 1
		}

		//The below equations set the integer and fractional parts of the frequency correctly for the ADF4351 to use.
		//They have been derived from information in the ADF4351 datasheet.
		freq_int_part = floor(freq);
		freq_frac_part = round(MODULUS*(freq - freq_int_part));

		if ((freq_int_part < INT_MIN) || (freq_int_part > 65535)){
			status = 1;
		}else{
			if (freq_frac_part > MODULUS){
				//The fractional part cannot be greater than the modulus value - if this condition is encountered, we need to return a 1 to indicate that the part cannot switch to this frequency.
				status = 1;
			}else{
				//The below statements transfer the values defined as defaults into the register buffer, but does not actually write it to the register itself.
				txBufSPI_ADF4351[ADF4351_REGISTER_0] &= ~(0xFFFFFFF << 3); //Clears bits [30:3] of ADF4351 Register 0 (which stores the INT and FRAC values)
				txBufSPI_ADF4351[ADF4351_REGISTER_0] |= freq_int_part << ADF4351_INT_VALUE_SHIFT | freq_frac_part << ADF4351_FRAC_VALUE_SHIFT; //Writes the new INT and FRAC values

				txBufSPI_ADF4351[ADF4351_REGISTER_1] &= ~(0x1 << ADF4351_PRESCALER_BIT_SHIFT); //Clears prescaler bit (bit 27) of ADF4351 Register 0. This may need to be reset
				txBufSPI_ADF4351[ADF4351_REGISTER_1] |= prescaler << ADF4351_PRESCALER_BIT_SHIFT; //Writes the new prescaler value

				txBufSPI_ADF4351[ADF4351_REGISTER_4] &= ~(0x7 << ADF4351_RFDIVIDERSEL_SHIFT); //Clears the RF divider bits (bits [22:20] of register 4)
				txBufSPI_ADF4351[ADF4351_REGISTER_4] |= rf_divider << ADF4351_RFDIVIDERSEL_SHIFT;

				//The below statement transfer the now correctly initialised values in the txBufSPI_ADF4351 buffer to the ADF4351 registers
				//ADF4351_Write(ADF4351_REGISTER_0, ADF4351_TOTAL_REG_NUM, txBufSPI_ADF4351);
				ADF4351_Write(ADF4351_REGISTER_0, 1, txBufSPI_ADF4351);
				ADF4351_Write(ADF4351_REGISTER_1, 1, txBufSPI_ADF4351);
				ADF4351_Write(ADF4351_REGISTER_4, 1, txBufSPI_ADF4351);
			}
		}
	}
	return status;
}


