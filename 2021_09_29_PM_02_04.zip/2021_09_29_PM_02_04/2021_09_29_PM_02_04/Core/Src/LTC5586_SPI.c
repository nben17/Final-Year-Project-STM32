/*
 * SPI.c
 *
 *  Created on: Oct 1, 2021
 *      Author: JerryBenny
 */

#include "math.h"
#include "stm32f4xx_hal.h"
#include "LTC5586_SPI.h"
#include "main.h"

//After every reset, start by writing 1 to SRST bit (bit 3) of register 22.
//This will reset the LTC5586 registers to their default value.
//Also put register 22's SDO_MODE bit = 1 (serial repeater mode).
//This will allow the LTC5586 to readback what you are sending

//Sets up the hardware and software of the LTC5586 to initial state
void initialiseLTC5586(void){
	LTC5586_HardReceiverSel(LTC5586_HARD_RFA_SEL); //Selecting RFA will put the GPIO pin into the HIGH state. From that point onwards, the 23rd (last register) can be used to select between which RF input to use - (1 = RFA (low freq) 0 = RFB (high freq))
	initialiseLTC5586SPI();
}

//Function to initialise LTC5586 SPI registers.
//In order for LTC5586 to communicate with the STM32, we need to send two bytes of data per transfer.
//This needs to be set up by the initialiseLTC5586SPIRegisters function
//Refer to the comments for the LTC5586_Write function for more information
void initialiseLTC5586SPI(void){
	//Set the LTC5586_CSB Pin high (default state). The MCU will pull it low to initiate communication.
	HAL_GPIO_WritePin(GPIOB,LTC5586_CSB_Pin,GPIO_PIN_SET);
	HAL_Delay(1);
	HAL_GPIO_WritePin(GPIOB,LTC5586_SCK_Pin,GPIO_PIN_RESET);
	HAL_Delay(1);
	HAL_GPIO_WritePin(GPIOB,LTC5586_MOSI_Pin,GPIO_PIN_RESET);
	HAL_Delay(1);

	//The below statements transfer the values defined as defaults into the register buffer, but does not actually write it to the register itself.
	txBufSPI_LTC5586[LTC5586_IM3QY_REG] = LTC5586_IM_DEFAULT;
	txBufSPI_LTC5586[LTC5586_IM3QX_REG] = LTC5586_IM_DEFAULT;
	txBufSPI_LTC5586[LTC5586_IM3IY_REG] = LTC5586_IM_DEFAULT;
	txBufSPI_LTC5586[LTC5586_IM3IX_REG] = LTC5586_IM_DEFAULT;
	txBufSPI_LTC5586[LTC5586_IM2QX_REG] = LTC5586_IM_DEFAULT;
	txBufSPI_LTC5586[LTC5586_IM2IX_REG] = LTC5586_IM_DEFAULT;
	txBufSPI_LTC5586[LTC5586_HD3QY_REG] = LTC5586_HD3QY_DEFAULT;
	txBufSPI_LTC5586[LTC5586_HD3QX_REG] = LTC5586_HD3QX_DEFAULT;
	txBufSPI_LTC5586[LTC5586_HD3IY_REG] = LTC5586_HD3IY_DEFAULT ;
	txBufSPI_LTC5586[LTC5586_HD3IX_REG] = LTC5586_HD3IX_DEFAULT ;
	txBufSPI_LTC5586[LTC5586_HD2QY_REG] = LTC5586_HD2QY_DEFAULT;
	txBufSPI_LTC5586[LTC5586_HD2QX_REG] = LTC5586_HD2QX_DEFAULT;
	txBufSPI_LTC5586[LTC5586_HD2IY_REG] = LTC5586_HD2IY_DEFAULT;
	txBufSPI_LTC5586[LTC5586_HD2IX_REG] = LTC5586_HD2IX_DEFAULT;
	txBufSPI_LTC5586[LTC5586_DCOI_REG] = LTC5586_DCOI_DEFAULT;
	txBufSPI_LTC5586[LTC5586_DCOQ_REG] = LTC5586_DCOQ_DEFAULT;
	txBufSPI_LTC5586[LTC5586_ATT_IP3IC_REG] = LTC5586_ATT_DEFAULT << LTC5586_ATT_SHIFT | LTC5586_IP3IC_DEFAULT << LTC5586_IP3IC_SHIFT;
	txBufSPI_LTC5586[LTC5586_GERR_IP3CC_REG] = LTC5586_GERR_DEFAULT << LTC5586_GERR_SHIFT | LTC5586_IP3CC_DEFAULT << LTC5586_IP3CC_SHIFT;
	txBufSPI_LTC5586[LTC5586_LVCM_CF1_REG] = LTC5586_LVCM_DEFAULT << LTC5586_LVCM_SHIFT | LTC5586_CF1_DEFAULT << LTC5586_CF1_SHIFT;
	txBufSPI_LTC5586[LTC5586_BAND_LF1_CF2_REG] = LTC5586_BAND_DEFAULT << LTC5586_BAND_SHIFT | LTC5586_LF1_DEFAULT << LTC5586_LF1_SHIFT | LTC5586_CF2_DEFAULT << LTC5586_CF2_SHIFT;
	txBufSPI_LTC5586[LTC5586_PHA81_REG] = LTC5586_PHA81_DEFAULT;
	txBufSPI_LTC5586[LTC5586_PHA0_AMPG_AMPCC_AMPIC_REG] = LTC5586_PHA0_DEFAULT << LTC5586_PHA0_SHIFT | LTC5586_AMPG_DEFAULT << LTC5586_AMPG_SHIFT | LTC5586_AMPCC_DEFAULT << LTC5586_AMPCC_SHIFT | LTC5586_AMPIC_DEFAULT << LTC5586_AMPIC_SHIFT;
	txBufSPI_LTC5586[LTC5586_SRST_SDOMODE_REG] = LTC5586_SRST_SDOMODE_RESERVED_DEFAULT | LTC5586_SRST_DEFAULT << LTC5586_SRST_SHIFT | LTC5586_SDOMODE_DEFAULT << LTC5586_SDOMODE_SHIFT;
	txBufSPI_LTC5586[LTC5586_CHIPID_RFSW_REG] = LTC5586_CHIPID_RFSW_RESERVED_DEFAULT | LTC5586_RFSW_DEFAULT << LTC5586_RFSW_SHIFT;

	//The below statements transfer the now correctly initialised values in the txBufSPI_LTC5586 buffer to the LTC5586 registers
	uint8_t counter = 0;
	while (counter < LTC5586_TOTAL_REG_NUM){
		LTC5586_Write(counter, 1, txBufSPI_LTC5586);
		counter++;
	}
}

//The read/write process for the 8 bit wide LTC5586 SPI registers is as follows:
//1. We need to first send a byte that contains:
//a. 0/1 in the MSB (to indicate write/read respectively)
//b. The register number to read/write from in the next 7 bits

//Function to read registers from LTC5586
//addr represents the starting byte to read (between 0 and 23)
//totalBytesToRead represents the total number of bytes that need to be read starting at addr
//rxBuf is a pointer to the buffer where the received values will be stored
void LTC5586_Read(uint8_t addr, uint8_t totalBytesToRead, uint8_t * rxBuf){
	uint8_t totalBytesRead = 0; //Keeps track of how many bytes have been read
	uint8_t byteToRead = addr; //keeps track of which byte is about to be read
	uint8_t bitToRead = 7; //The bit that is to be read. All transfers are MSB first, so bit 7 is the first bit to arrive
	uint8_t bitToAddress = 7; //Since LTC5586 operates in readback mode, we have to first transmit a 1 followed by the register address in order to read from the part. This counter keeps track of which bit to transmit.

	HAL_Delay(1);

	while (totalBytesRead < totalBytesToRead){
		//Set the CSB signal low to select the LTC5586 chip and start the read
		HAL_GPIO_WritePin(GPIOB,LTC5586_CSB_Pin,GPIO_PIN_RESET);

		//bitToRead represents the bit of data that is next to be read.
		bitToRead = 7;
		//bitToAddress represents the next bit from the address byte that is to be transmitted
		bitToAddress = 7;
		rxBuf[byteToRead] = 0; //Clears current value for the byte stored in the receive buffer
		//To read from LTC5586, first we need to transmit a 1, followed by the address. The below loop cycles through and transmits each bit in the address byte
		while (bitToAddress < 8){
			//Resets the clock pin, so that a rising edge can be set
			HAL_GPIO_WritePin(GPIOB, LTC5586_SCK_Pin, GPIO_PIN_RESET);
			HAL_Delay(1);
			//The bit to transmit is set, followed by a rising edge on the clock signal pin to clock the bit into the LTC5586.
			HAL_GPIO_WritePin(GPIOB, LTC5586_MOSI_Pin, ((128 | byteToRead) & (1 << bitToAddress))); //ByteToRead ORed with 128U because when reading, the first bit in the address byte must be 1
			HAL_Delay(1);
			//Setting the clock pin creates the rising edge required to clock in the bit
			HAL_GPIO_WritePin(GPIOB, LTC5586_SCK_Pin, GPIO_PIN_SET);
			bitToAddress--;
			HAL_Delay(1);
		}
		HAL_GPIO_WritePin(GPIOB, LTC5586_SCK_Pin, GPIO_PIN_RESET); //When switching from reading to writing, we need to reset the clock to low so that the first rising edge is not missed.
		HAL_Delay(1);
		//In the for loop below, we rely on underflow of the variable bitToRead. As we subtract 1 from 0, it will give 255, breaking us out of the loop.
		while (bitToRead < 8){
			HAL_GPIO_WritePin(GPIOB, LTC5586_SCK_Pin, GPIO_PIN_SET);
			HAL_Delay(1);
			//Having cleared the appropriate byte in the receive buffer (set to zero), ORing each bit with what is read from the part will set the appropriate byte to the value received from the device.
			rxBuf[byteToRead] |= HAL_GPIO_ReadPin(GPIOB, LTC5586_MISO_Pin) << bitToRead;
			HAL_Delay(1);
			HAL_GPIO_WritePin(GPIOB, LTC5586_SCK_Pin, GPIO_PIN_RESET);
			bitToRead--;
			HAL_Delay(1);
		}
		HAL_GPIO_WritePin(GPIOB,LTC5586_CSB_Pin,GPIO_PIN_SET);
		//Increments the byte number which is about to be read
		byteToRead++;
		//If we are about to read the 24th byte, then start from 0 again instead
		if (byteToRead > 23){
			byteToRead = 0;
		}
		//Increment the number of bytes that have been read
		totalBytesRead++;
	}

	//Set the CSB signal high to deselect the LTC5586 chip and signal end of read
	HAL_GPIO_WritePin(GPIOB,LTC5586_CSB_Pin,GPIO_PIN_SET);
	HAL_Delay(1);
	//Sets the MOSI pin low to avoid sending any further bits to the part
	HAL_GPIO_WritePin(GPIOB,LTC5586_MOSI_Pin,GPIO_PIN_RESET);
	HAL_Delay(1);
	//Sets the clock pin low in preparation for the next transmission
	HAL_GPIO_WritePin(GPIOB,LTC5586_SCK_Pin,GPIO_PIN_RESET);
	HAL_Delay(1);
}

//Function to write registers to LTC5586
void LTC5586_Write(uint8_t addr, uint8_t totalBytesToWrite, uint8_t * txBuf){
	uint8_t totalBytesWritten = 0; //Keeps track of how many bytes have been written
	uint8_t byteToWrite = addr; //keeps track of which byte is about to be written
	uint8_t bitToWrite = 7; //This counter keeps track of which bit to WRITE next (all the address bits have to be transmitted before the write bits are transmitted).
	uint8_t bitToAddress = 7; //This counter keeps track of which address bit to write next.
	//uint8_t tempWrite = 0;

	//Set the CSB signal low to select the LTC5586 chip and start the read
	//HAL_GPIO_WritePin(GPIOB,LTC5586_CSB_Pin,GPIO_PIN_RESET);
	HAL_Delay(1);
	while (totalBytesWritten < totalBytesToWrite){
		HAL_GPIO_WritePin(GPIOB,LTC5586_CSB_Pin,GPIO_PIN_RESET);
		bitToWrite = 7;
		bitToAddress = 7;
		//To read from LTC5586, first we need to transmit a 1, followed by the address
		while (bitToAddress < 8){
			HAL_GPIO_WritePin(GPIOB, LTC5586_SCK_Pin, GPIO_PIN_RESET);
			HAL_Delay(1);
			//tempWrite = (byteToWrite & (1U << bitToAddress));
			//HAL_GPIO_WritePin(GPIOB, LTC5586_MOSI_Pin, tempWrite);
			HAL_GPIO_WritePin(GPIOB, LTC5586_MOSI_Pin, (byteToWrite & (1 << bitToAddress)));
			HAL_Delay(1);
			HAL_GPIO_WritePin(GPIOB, LTC5586_SCK_Pin, GPIO_PIN_SET);
			bitToAddress--;
			HAL_Delay(1);
		}
		//In the for loop below, we rely on underflow of the variable bitToRead. As we subtract 1 from 0, it will give 255, breaking us out of the loop.
		while (bitToWrite < 8){
			HAL_GPIO_WritePin(GPIOB, LTC5586_SCK_Pin, GPIO_PIN_RESET);
			HAL_Delay(1);
			//tempWrite = txBuf[byteToWrite] & (1U << bitToWrite);
			//HAL_GPIO_WritePin(GPIOB, LTC5586_MOSI_Pin, tempWrite);
			HAL_GPIO_WritePin(GPIOB, LTC5586_MOSI_Pin, txBuf[byteToWrite] & (1 << bitToWrite));
			HAL_Delay(1);
			HAL_GPIO_WritePin(GPIOB, LTC5586_SCK_Pin, GPIO_PIN_SET);
			bitToWrite--;
			HAL_Delay(1);
		}
		HAL_GPIO_WritePin(GPIOB,LTC5586_CSB_Pin,GPIO_PIN_SET);
		//Increments the byte number which is about to be read
		byteToWrite++;

		//If we are about to write the 24th byte, then start from 0 again instead
		if (byteToWrite > 23){
			byteToWrite = 0;
		}
		totalBytesWritten++;
	}
	//Set the CSB signal high to unselect the LTC5586 chip and signal end of read
	HAL_GPIO_WritePin(GPIOB,LTC5586_CSB_Pin,GPIO_PIN_SET);
	HAL_Delay(1);
	HAL_GPIO_WritePin(GPIOB,LTC5586_MOSI_Pin,GPIO_PIN_RESET);
	HAL_Delay(1);
	HAL_GPIO_WritePin(GPIOB,LTC5586_SCK_Pin,GPIO_PIN_RESET);
	HAL_Delay(1);
	//return status;
}

//Function which takes an integer argument 0 or 1 and selects RFA (if 1) or RFB (if 0) - note that bit 0 of register 23 (last register has to be 1 for the switching to work with hardware)
uint8_t LTC5586_HardReceiverSel(uint8_t receiver){
	uint8_t ok = 1;
	if (receiver == LTC5586_HARD_RFA_SEL){
		//Selects RF input A by setting the RF sel pin
		HAL_GPIO_WritePin(LTC5586_RF_Sel_GPIO_Port,LTC5586_RF_Sel_Pin,GPIO_PIN_SET);
	}else if (receiver == LTC5586_HARD_RFB_SEL){
		//Selects RF input B by resetting the RF sel pin
		HAL_GPIO_WritePin(LTC5586_RF_Sel_GPIO_Port,LTC5586_RF_Sel_Pin,GPIO_PIN_RESET);
	}else{
		ok = 0;
	}
	return ok;
}

//The below function takes in a floating point value representing the frequency that the user would like to tune to in MHz and performs the required
//register modifications to the LTC5586 to tune it to that frequency (if possible). If this frequency is not achievable, this function returns 1.
uint8_t LTC5586_ChangeFrequency(float freq){
	//This variable is used to keep track of whether the chosen frequency is available
	uint8_t status = 0;
	//Limits on the minimum and maximum frequency of guaranteed performance of the part, if a frequency outside this range is demanded, return a value indicating impossibility.
	if ((freq < 300) || (freq > 6000)){
		status = 1;
	}else{
		txBufSPI_LTC5586[LTC5586_ATT_IP3IC_REG] &= ~(0x1F << LTC5586_ATT_SHIFT); //Resets the attenuation portion of this register
		txBufSPI_LTC5586[LTC5586_LVCM_CF1_REG] &= ~(0x1F << LTC5586_CF1_SHIFT); //Resets the CF1 portion (bits [4:0]) of the transmit buffer byte that controls LVCM and CF1, so that the new CF1 value can be written.
		txBufSPI_LTC5586[LTC5586_BAND_LF1_CF2_REG] &= ~(0xFF); //Resets this entire transmit buffer byte that controls the BAND, LF1 and CF2 registers, so that these settings can be rewritten.
		txBufSPI_LTC5586[LTC5586_PHA0_AMPG_AMPCC_AMPIC_REG] &= ~(0x7 << LTC5586_AMPG_SHIFT); //Resets the amplifier gain portion of this register
		txBufSPI_LTC5586[LTC5586_CHIPID_RFSW_REG] &= ~(0x1); //Resets the RFSW bit in the final transmit buffer byte, which is used to select between RFA (low frequency receiver) and RFB (high frequency receiver)
		if ((300 <= freq) && (freq < 339)){
			txBufSPI_LTC5586[LTC5586_ATT_IP3IC_REG] |= 10 << LTC5586_ATT_SHIFT; //Attenuation of 10 and gain of 0 works well for the lower frequencies
			//CF1 = 31, BAND = 0, LF1 = 3, CF2 = 31
			txBufSPI_LTC5586[LTC5586_LVCM_CF1_REG] |= 31 << LTC5586_CF1_SHIFT;
			txBufSPI_LTC5586[LTC5586_BAND_LF1_CF2_REG] |= 0 << LTC5586_BAND_SHIFT | 3 << LTC5586_LF1_SHIFT | 31 << LTC5586_CF2_SHIFT;
			txBufSPI_LTC5586[LTC5586_PHA0_AMPG_AMPCC_AMPIC_REG] |= 0 << LTC5586_AMPG_SHIFT; //Amplifier gain of 0 works well for the lower frequencies
			txBufSPI_LTC5586[LTC5586_CHIPID_RFSW_REG] |= 0x1; //Selects RFA as the receiver input, good for frequencies below approximately 550 MHz
		}else if ((339 <= freq) && (freq < 398)){
			txBufSPI_LTC5586[LTC5586_ATT_IP3IC_REG] |= 10 << LTC5586_ATT_SHIFT; //Attenuation of 10 and gain of 0 works well for the lower frequencies
			//CF1 = 21, BAND = 0, LF1 = 3, CF2 = 24
			txBufSPI_LTC5586[LTC5586_LVCM_CF1_REG] |= 21 << LTC5586_CF1_SHIFT;
			txBufSPI_LTC5586[LTC5586_BAND_LF1_CF2_REG] |= 0 << LTC5586_BAND_SHIFT | 3 << LTC5586_LF1_SHIFT | 24 << LTC5586_CF2_SHIFT;
			txBufSPI_LTC5586[LTC5586_PHA0_AMPG_AMPCC_AMPIC_REG] |= 0 << LTC5586_AMPG_SHIFT; //Amplifier gain of 0 works well for the lower frequencies
			txBufSPI_LTC5586[LTC5586_CHIPID_RFSW_REG] |= 0x1; //Selects RFA as the receiver input, good for frequencies below approximately 550 MHz
		}else if ((398 <= freq) && (freq < 419)){
			txBufSPI_LTC5586[LTC5586_ATT_IP3IC_REG] |= 10 << LTC5586_ATT_SHIFT; //Attenuation of 10 and gain of 0 works well for the lower frequencies
			//CF1 = 14, BAND = 0, LF1 = 3, CF2 = 23
			txBufSPI_LTC5586[LTC5586_LVCM_CF1_REG] |= 14 << LTC5586_CF1_SHIFT;
			txBufSPI_LTC5586[LTC5586_BAND_LF1_CF2_REG] |= 0 << LTC5586_BAND_SHIFT | 3 << LTC5586_LF1_SHIFT | 23 << LTC5586_CF2_SHIFT;
			txBufSPI_LTC5586[LTC5586_PHA0_AMPG_AMPCC_AMPIC_REG] |= 0 << LTC5586_AMPG_SHIFT; //Amplifier gain of 0 works well for the lower frequencies
			txBufSPI_LTC5586[LTC5586_CHIPID_RFSW_REG] |= 0x1; //Selects RFA as the receiver input, good for frequencies below approximately 550 MHz
		}else if ((419 <= freq) && (freq < 556)){
			txBufSPI_LTC5586[LTC5586_ATT_IP3IC_REG] |= 10 << LTC5586_ATT_SHIFT; //Attenuation of 10 and gain of 0 works well for the lower frequencies
			//CF1 = 17, BAND = 0, LF1 = 2, CF2 = 31
			txBufSPI_LTC5586[LTC5586_LVCM_CF1_REG] |= 17 << LTC5586_CF1_SHIFT;
			txBufSPI_LTC5586[LTC5586_BAND_LF1_CF2_REG] |= 0 << LTC5586_BAND_SHIFT | 2 << LTC5586_LF1_SHIFT | 31 << LTC5586_CF2_SHIFT;
			txBufSPI_LTC5586[LTC5586_PHA0_AMPG_AMPCC_AMPIC_REG] |= 0 << LTC5586_AMPG_SHIFT; //Amplifier gain of 0 works well for the lower frequencies
			txBufSPI_LTC5586[LTC5586_CHIPID_RFSW_REG] |= 0x1; //Selects RFA as the receiver input, good for frequencies below approximately 550 MHz
		}else if ((556 <= freq) && (freq < 625)){
			txBufSPI_LTC5586[LTC5586_ATT_IP3IC_REG] |= 10 << LTC5586_ATT_SHIFT; //Attenuation of 10 and gain of 0 works well for the lower frequencies
			//CF1 = 10, BAND = 0, LF1 = 2, CF2 = 23
			txBufSPI_LTC5586[LTC5586_LVCM_CF1_REG] |= 10 << LTC5586_CF1_SHIFT;
			txBufSPI_LTC5586[LTC5586_BAND_LF1_CF2_REG] |= 0 << LTC5586_BAND_SHIFT | 2 << LTC5586_LF1_SHIFT | 23 << LTC5586_CF2_SHIFT;
			txBufSPI_LTC5586[LTC5586_PHA0_AMPG_AMPCC_AMPIC_REG] |= 0 << LTC5586_AMPG_SHIFT; //Amplifier gain of 0 works well for the lower frequencies
			txBufSPI_LTC5586[LTC5586_CHIPID_RFSW_REG] |= 0x0; //Selects RFB as the receiver input, good for frequencies above approximately 550 MHz
		}else if ((625 <= freq) && (freq < 801)){
			txBufSPI_LTC5586[LTC5586_ATT_IP3IC_REG] |= 10 << LTC5586_ATT_SHIFT; //Attenuation of 10 and gain of 0 works well for the lower frequencies
			//CF1 = 15, BAND = 0, LF1 = 1, CF2 = 31
			txBufSPI_LTC5586[LTC5586_LVCM_CF1_REG] |= 15 << LTC5586_CF1_SHIFT;
			txBufSPI_LTC5586[LTC5586_BAND_LF1_CF2_REG] |= 0 << LTC5586_BAND_SHIFT | 1 << LTC5586_LF1_SHIFT | 31 << LTC5586_CF2_SHIFT;
			txBufSPI_LTC5586[LTC5586_PHA0_AMPG_AMPCC_AMPIC_REG] |= 0 << LTC5586_AMPG_SHIFT; //Amplifier gain of 0 works well for the lower frequencies
			txBufSPI_LTC5586[LTC5586_CHIPID_RFSW_REG] |= 0x0; //Selects RFB as the receiver input, good for frequencies above approximately 550 MHz
		}else if ((801 <= freq) && (freq < 831)){
			txBufSPI_LTC5586[LTC5586_ATT_IP3IC_REG] |= 10 << LTC5586_ATT_SHIFT; //Attenuation of 10 and gain of 0 works well for the lower frequencies
			//CF1 = 14, BAND = 0, LF1 = 1, CF2 = 27
			txBufSPI_LTC5586[LTC5586_LVCM_CF1_REG] |= 14 << LTC5586_CF1_SHIFT;
			txBufSPI_LTC5586[LTC5586_BAND_LF1_CF2_REG] |= 0 << LTC5586_BAND_SHIFT | 1 << LTC5586_LF1_SHIFT | 27 << LTC5586_CF2_SHIFT;
			txBufSPI_LTC5586[LTC5586_PHA0_AMPG_AMPCC_AMPIC_REG] |= 0 << LTC5586_AMPG_SHIFT; //Amplifier gain of 0 works well for the lower frequencies
			txBufSPI_LTC5586[LTC5586_CHIPID_RFSW_REG] |= 0x0; //Selects RFB as the receiver input, good for frequencies above approximately 550 MHz
		}else if ((831 <= freq) && (freq < 1046)){
			txBufSPI_LTC5586[LTC5586_ATT_IP3IC_REG] |= 10 << LTC5586_ATT_SHIFT; //Attenuation of 10 and gain of 0 works well for the lower frequencies
			//CF1 = 8, BAND = 0, LF1 = 1, CF2 = 21
			txBufSPI_LTC5586[LTC5586_LVCM_CF1_REG] |= 8 << LTC5586_CF1_SHIFT;
			txBufSPI_LTC5586[LTC5586_BAND_LF1_CF2_REG] |= 0 << LTC5586_BAND_SHIFT | 1 << LTC5586_LF1_SHIFT | 21 << LTC5586_CF2_SHIFT;
			txBufSPI_LTC5586[LTC5586_PHA0_AMPG_AMPCC_AMPIC_REG] |= 0 << LTC5586_AMPG_SHIFT; //Amplifier gain of 0 works well for the lower frequencies
			txBufSPI_LTC5586[LTC5586_CHIPID_RFSW_REG] |= 0x0; //Selects RFB as the receiver input, good for frequencies above approximately 550 MHz
		}else if ((1046 <= freq) && (freq < 1242)){
			txBufSPI_LTC5586[LTC5586_ATT_IP3IC_REG] |= 10 << LTC5586_ATT_SHIFT; //Attenuation of 10 and gain of 0 works well for the lower frequencies
			//CF1 = 31, BAND = 1, LF1 = 3, CF2 = 31
			txBufSPI_LTC5586[LTC5586_LVCM_CF1_REG] |= 31 << LTC5586_CF1_SHIFT;
			txBufSPI_LTC5586[LTC5586_BAND_LF1_CF2_REG] |= 1 << LTC5586_BAND_SHIFT | 3 << LTC5586_LF1_SHIFT | 31 << LTC5586_CF2_SHIFT;
			txBufSPI_LTC5586[LTC5586_PHA0_AMPG_AMPCC_AMPIC_REG] |= 0 << LTC5586_AMPG_SHIFT; //Amplifier gain of 0 works well for the lower frequencies
			txBufSPI_LTC5586[LTC5586_CHIPID_RFSW_REG] |= 0x0; //Selects RFB as the receiver input, good for frequencies above approximately 550 MHz
		}else if ((1242 <= freq) && (freq < 1411)){
			txBufSPI_LTC5586[LTC5586_ATT_IP3IC_REG] |= 10 << LTC5586_ATT_SHIFT; //Attenuation of 10 and gain of 0 works well for the lower frequencies
			//CF1 = 21, BAND = 1, LF1 = 3, CF2 = 28
			txBufSPI_LTC5586[LTC5586_LVCM_CF1_REG] |= 21 << LTC5586_CF1_SHIFT;
			txBufSPI_LTC5586[LTC5586_BAND_LF1_CF2_REG] |= 1 << LTC5586_BAND_SHIFT | 3 << LTC5586_LF1_SHIFT | 28 << LTC5586_CF2_SHIFT;
			txBufSPI_LTC5586[LTC5586_PHA0_AMPG_AMPCC_AMPIC_REG] |= 0 << LTC5586_AMPG_SHIFT; //Amplifier gain of 0 works well for the lower frequencies
			txBufSPI_LTC5586[LTC5586_CHIPID_RFSW_REG] |= 0x0; //Selects RFB as the receiver input, good for frequencies above approximately 550 MHz
		}else if ((1411 <= freq) && (freq < 1696)){
			txBufSPI_LTC5586[LTC5586_ATT_IP3IC_REG] |= 10 << LTC5586_ATT_SHIFT; //Attenuation of 10 and gain of 0 works well for the lower frequencies
			//CF1 = 17, BAND = 1, LF1 = 2, CF2 = 26
			txBufSPI_LTC5586[LTC5586_LVCM_CF1_REG] |= 17 << LTC5586_CF1_SHIFT;
			txBufSPI_LTC5586[LTC5586_BAND_LF1_CF2_REG] |= 1 << LTC5586_BAND_SHIFT | 2 << LTC5586_LF1_SHIFT | 26 << LTC5586_CF2_SHIFT;
			txBufSPI_LTC5586[LTC5586_PHA0_AMPG_AMPCC_AMPIC_REG] |= 0 << LTC5586_AMPG_SHIFT; //Amplifier gain of 0 works well for the lower frequencies
			txBufSPI_LTC5586[LTC5586_CHIPID_RFSW_REG] |= 0x0; //Selects RFB as the receiver input, good for frequencies above approximately 550 MHz
		}else if ((1696 <= freq) && (freq < 2070)){
			txBufSPI_LTC5586[LTC5586_ATT_IP3IC_REG] |= 10 << LTC5586_ATT_SHIFT; //Attenuation of 10 and gain of 0 works well for the lower frequencies
			//CF1 = 15, BAND = 1, LF1 = 1, CF2 = 31
			txBufSPI_LTC5586[LTC5586_LVCM_CF1_REG] |= 15 << LTC5586_CF1_SHIFT;
			txBufSPI_LTC5586[LTC5586_BAND_LF1_CF2_REG] |= 1 << LTC5586_BAND_SHIFT | 1 << LTC5586_LF1_SHIFT | 31 << LTC5586_CF2_SHIFT;
			txBufSPI_LTC5586[LTC5586_PHA0_AMPG_AMPCC_AMPIC_REG] |= 0 << LTC5586_AMPG_SHIFT; //Amplifier gain of 0 works well for the lower frequencies
			txBufSPI_LTC5586[LTC5586_CHIPID_RFSW_REG] |= 0x0; //Selects RFB as the receiver input, good for frequencies above approximately 550 MHz
		}else if ((2070 <= freq) && (freq < 2470)){
			txBufSPI_LTC5586[LTC5586_ATT_IP3IC_REG] |= 10 << LTC5586_ATT_SHIFT; //Attenuation of 10 and gain of 0 works well for the lower frequencies
			//CF1 = 8, BAND = 1, LF1 = 1, CF2 = 21
			txBufSPI_LTC5586[LTC5586_LVCM_CF1_REG] |= 8 << LTC5586_CF1_SHIFT;
			txBufSPI_LTC5586[LTC5586_BAND_LF1_CF2_REG] |= 1 << LTC5586_BAND_SHIFT | 1 << LTC5586_LF1_SHIFT | 21 << LTC5586_CF2_SHIFT;
			txBufSPI_LTC5586[LTC5586_PHA0_AMPG_AMPCC_AMPIC_REG] |= 0 << LTC5586_AMPG_SHIFT; //Amplifier gain of 0 works well for the lower frequencies
			txBufSPI_LTC5586[LTC5586_CHIPID_RFSW_REG] |= 0x0; //Selects RFB as the receiver input, good for frequencies above approximately 550 MHz
		}else if ((2470 <= freq) && (freq < 2980)){
			txBufSPI_LTC5586[LTC5586_ATT_IP3IC_REG] |= 10 << LTC5586_ATT_SHIFT; //Attenuation of 10 and gain of 0 works well for the lower frequencies
			//CF1 = 2, BAND = 1, LF1 = 1, CF2 = 10
			txBufSPI_LTC5586[LTC5586_LVCM_CF1_REG] |= 2 << LTC5586_CF1_SHIFT;
			txBufSPI_LTC5586[LTC5586_BAND_LF1_CF2_REG] |= 1 << LTC5586_BAND_SHIFT | 1 << LTC5586_LF1_SHIFT | 10 << LTC5586_CF2_SHIFT;
			txBufSPI_LTC5586[LTC5586_PHA0_AMPG_AMPCC_AMPIC_REG] |= 0 << LTC5586_AMPG_SHIFT; //Amplifier gain of 0 works well for the lower frequencies
			txBufSPI_LTC5586[LTC5586_CHIPID_RFSW_REG] |= 0x0; //Selects RFB as the receiver input, good for frequencies above approximately 550 MHz
		}else if ((2980 <= freq) && (freq < 3500)){
			txBufSPI_LTC5586[LTC5586_ATT_IP3IC_REG] |= 10 << LTC5586_ATT_SHIFT; //Attenuation of 10 and gain of 0 works well for the lower frequencies
			//CF1 = 1, BAND = 1, LF1 = 1, CF2 = 19
			txBufSPI_LTC5586[LTC5586_LVCM_CF1_REG] |= 1 << LTC5586_CF1_SHIFT;
			txBufSPI_LTC5586[LTC5586_BAND_LF1_CF2_REG] |= 1 << LTC5586_BAND_SHIFT | 1 << LTC5586_LF1_SHIFT | 19 << LTC5586_CF2_SHIFT;
			txBufSPI_LTC5586[LTC5586_PHA0_AMPG_AMPCC_AMPIC_REG] |= 0 << LTC5586_AMPG_SHIFT; //Amplifier gain of 0 works well for the lower frequencies
			txBufSPI_LTC5586[LTC5586_CHIPID_RFSW_REG] |= 0x0; //Selects RFB as the receiver input, good for frequencies above approximately 550 MHz
		}else if ((3500 <= freq) && (freq < 6000)){
			txBufSPI_LTC5586[LTC5586_ATT_IP3IC_REG] |= 10 << LTC5586_ATT_SHIFT; //Attenuation of 10 and gain of 0 works well for the lower frequencies
			//CF1 = 0, BAND = 1, LF1 = 0, CF2 = 0
			txBufSPI_LTC5586[LTC5586_LVCM_CF1_REG] |= 0 << LTC5586_CF1_SHIFT;
			txBufSPI_LTC5586[LTC5586_BAND_LF1_CF2_REG] |= 1 << LTC5586_BAND_SHIFT | 0 << LTC5586_LF1_SHIFT | 0 << LTC5586_CF2_SHIFT;
			txBufSPI_LTC5586[LTC5586_PHA0_AMPG_AMPCC_AMPIC_REG] |= 0 << LTC5586_AMPG_SHIFT; //Amplifier gain of 0 works well for the lower frequencies
			txBufSPI_LTC5586[LTC5586_CHIPID_RFSW_REG] |= 0x0; //Selects RFB as the receiver input, good for frequencies above approximately 550 MHz
		}
	}

	//Write the modified registers to the LTC5586
	LTC5586_Write(LTC5586_ATT_IP3IC_REG, 1, txBufSPI_LTC5586);
	LTC5586_Write(LTC5586_LVCM_CF1_REG, 1, txBufSPI_LTC5586);
	LTC5586_Write(LTC5586_BAND_LF1_CF2_REG, 1, txBufSPI_LTC5586);
	LTC5586_Write(LTC5586_PHA0_AMPG_AMPCC_AMPIC_REG, 1, txBufSPI_LTC5586);
	LTC5586_Write(LTC5586_CHIPID_RFSW_REG, 1, txBufSPI_LTC5586);


	//Test by reading, update the rxBuf values
	LTC5586_Read(LTC5586_ATT_IP3IC_REG, 1, rxBufSPI_LTC5586);
	LTC5586_Read(LTC5586_LVCM_CF1_REG,1,rxBufSPI_LTC5586);
	LTC5586_Read(LTC5586_PHA0_AMPG_AMPCC_AMPIC_REG, 1, rxBufSPI_LTC5586);
	LTC5586_Read(LTC5586_BAND_LF1_CF2_REG,1,rxBufSPI_LTC5586);
	return status;
}
