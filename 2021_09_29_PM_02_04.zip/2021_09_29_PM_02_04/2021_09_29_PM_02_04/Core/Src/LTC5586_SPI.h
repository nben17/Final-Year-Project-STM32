/*
 * SPI.h
 *
 *  Created on: Oct 2, 2021
 *      Author: JerryBenny
 */

#ifndef SRC_LTC5586_SPI_H_
	//Include the SPI function header if not defined
	#define SRC_LTC5586_SPI_H_

	//Dependencies
	#include "math.h"
	#include "stm32f4xx_hal.h"

	//Definitions
		//Defines the number of registers there are in total in the LTC5586
		#define LTC5586_TOTAL_REG_NUM 24
		//Defines the register numbers for the IM3 (third order intermodulation) compensation values
		#define LTC5586_IM3QY_REG 0
		#define LTC5586_IM3QX_REG 1
		#define LTC5586_IM3IY_REG 2
		#define LTC5586_IM3IX_REG 3
		//Defines the register numbers for the IM2 (second order intermodulation) compensation values
		#define LTC5586_IM2QX_REG 4
		#define LTC5586_IM2IX_REG 5
		//Defines the register numbers for the HD3 (third order harmonic distortion) compensation values
		#define LTC5586_HD3QY_REG 6
		#define LTC5586_HD3QX_REG 7
		#define LTC5586_HD3IY_REG 8
		#define LTC5586_HD3IX_REG 9
		//Defines the register numbers for the HD2 (second order harmonic distortion) compensation values
		#define LTC5586_HD2QY_REG 10
		#define LTC5586_HD2QX_REG 11
		#define LTC5586_HD2IY_REG 12
		#define LTC5586_HD2IX_REG 13
		//Defines the register numbers for the DC offset compensation values
		#define LTC5586_DCOI_REG 14
		#define LTC5586_DCOQ_REG 15
		//The register number for attenuation and IP3IC (input 3rd order intercept point IC control) adjust.
		#define LTC5586_ATT_IP3IC_REG 16
		//The register number for IQ gain ERROR adjust and IP3CC (input 3rd order intercept point CC control) adjust.
		#define LTC5586_GERR_IP3CC_REG 17
		//The register number for LVCM (LO Bias adjust, improves mixer IP3) and CF1 control (CF1 is part of the LO matching network)
		#define LTC5586_LVCM_CF1_REG 18
		//The register number for BAND (LO band matching select), LF1 control (LF1 is part of the LO matching network) and CF control (CF2 also part of LO matching network)
		#define LTC5586_BAND_LF1_CF2_REG 19
		//The register number which contains bits [8:1] of the phase error adjust bits
		#define LTC5586_PHA81_REG 20
		//The register number which contains bit 0 of the phase error adjust bits, IF amplifier gain adjust bits, and IF amplifier IM3 (3rd order intermodulation distortion control) bits.
		#define LTC5586_PHA0_AMPG_AMPCC_AMPIC_REG 21
		//The register number which contains the SRST and SDO_MODE bits. The other bits in this register have default values which MUST not be changed.
		//Some of those bits are 1 by default, others are 0. These are defined by OR masks  below.
		#define LTC5586_SRST_SDOMODE_REG 22
		//The register which contains the RF switch state and chip identification bits.
		#define LTC5586_CHIPID_RFSW_REG 23

		//Defines the default values of the registers
		//Default value of 128 for the IM2 and IM3 adjustment registers provides best performance over the widest variety of temperatures.
		//At certain temperatures, other values of these registers may provide slight improvements, but not important enough to vary these.
		#define LTC5586_IM_DEFAULT 128
		//The below statements define the default HD3 adjustment values.
		//According to the performance characteristics of the LTC5586, it seems best performance in 3 order harmonics is achieved when HD3QX is 96, unlike the other 3rd order harmonic control registers
		//At most temperatures, HD3QY,HD3IY and HD3IX register values of 96 seem to provide good performance. HD3QX is different, however.
		#define LTC5586_HD3QX_DEFAULT 160
		#define LTC5586_HD3QY_DEFAULT 96
		#define LTC5586_HD3IY_DEFAULT 96
		#define LTC5586_HD3IX_DEFAULT 96
		//The below statements define the default HD2 adjustment values
		//The values are chosen based on the graphs provided in the LTC5586 datasheet
		#define LTC5586_HD2QY_DEFAULT 160
		#define LTC5586_HD2QX_DEFAULT 128
		#define LTC5586_HD2IY_DEFAULT 96
		#define LTC5586_HD2IX_DEFAULT 96
		//Below statements define the default DC offset values //0F
		#define LTC5586_DCOI_DEFAULT 0x0F
		#define LTC5586_DCOQ_DEFAULT 0x0F
		//Below statement defines the default ATTENUATION (ATT) value
		#define LTC5586_ATT_DEFAULT 10
		#define LTC5586_ATT_SHIFT 3
		//Setting IP3IC to 0 provides good OIP3 performance across the entire RF frequency range
		#define LTC5586_IP3IC_DEFAULT 0
		#define LTC5586_IP3IC_SHIFT 0
		//Setting GERR to 32 minimises the gain error, according to the LTC5586 datasheet, for 1900 MHz
		#define LTC5586_GERR_DEFAULT 32
		#define LTC5586_GERR_SHIFT 2
		//Setting IP3CC to 0 improves OIP3 performance across the entire RF frequency range
		#define LTC5586_IP3CC_DEFAULT 0
		#define LTC5586_IP3CC_SHIFT 0
		//Setting LVCM to 7 improves OIP3 performance over the entire RF frequency range
		#define LTC5586_LVCM_DEFAULT 7
		#define LTC5586_LVCM_SHIFT 5
		//The below selections mean that the device will default to 433.92 MHz when powered on
		#define LTC5586_CF1_DEFAULT 17
		#define LTC5586_CF1_SHIFT 0
		#define LTC5586_BAND_DEFAULT 0
		#define LTC5586_BAND_SHIFT 7
		#define LTC5586_LF1_DEFAULT 2
		#define LTC5586_LF1_SHIFT 5
		#define LTC5586_CF2_DEFAULT 31
		#define LTC5586_CF2_SHIFT 0
		//Default phase adjustment set to 0 degrees (by setting the PHA[8:0] bits to 256 (halfway between 0 and max value of 512)
		#define LTC5586_PHA81_DEFAULT 0x80
		#define LTC5586_PHA0_DEFAULT 0
		#define LTC5586_PHA0_SHIFT 7
		//Amplifier gain adjust default value - set to minimum gain by default
		#define LTC5586_AMPG_DEFAULT 0
		#define LTC5586_AMPG_SHIFT 4
		//Amplifier third order intermodulation adjust
		#define LTC5586_AMPCC_DEFAULT 2
		#define LTC5586_AMPCC_SHIFT 2
		//Amplifier third order intermodulation adjust
		#define LTC5586_AMPIC_DEFAULT 2
		#define LTC5586_AMPIC_SHIFT 0
		//Bits that define reset and SDO mode. Some of these bits need to be 1 always, so check before changing
		#define LTC5586_SRST_SDOMODE_RESERVED_DEFAULT 0xF0
		#define LTC5586_SRST_DEFAULT 0
		#define LTC5586_SRST_SHIFT 3
		#define LTC5586_SDOMODE_DEFAULT 0
		#define LTC5586_SDOMODE_SHIFT 2
		//Bit that selects between the RFA and RFB inputs.
		#define LTC5586_CHIPID_RFSW_RESERVED_DEFAULT 0
		#define LTC5586_RFSW_DEFAULT 1 //With the hardware RF input select pin high, changing this register will change the RF input that is selected. Default of 1 selects the RFA input (low freq, good for 433.92 MHz)
		#define LTC5586_RFSW_SHIFT 0

		//Numbers to switch between RFA and RFB by hardware pin
		#define LTC5586_HARD_RFB_SEL 0
		#define LTC5586_HARD_RFA_SEL 1

		//Variables
		//LTC5586 section
		//Location where the read values from LTC5586 will be stored
		uint8_t rxBufSPI_LTC5586[LTC5586_TOTAL_REG_NUM];
		//Location where the values to be transmitted to LTC5586 will be stored
		uint8_t txBufSPI_LTC5586[LTC5586_TOTAL_REG_NUM];

		//Function Declarations
		void initialiseLTC5586(void);
		void initialiseLTC5586SPI(void);
		void LTC5586_Read(uint8_t addr, uint8_t totalBytesToRead, uint8_t * rxBuf);
		void LTC5586_Write(uint8_t addr, uint8_t totalBytesToWrite, uint8_t * txBuf);
		uint8_t LTC5586_HardReceiverSel(uint8_t receiver);
		uint8_t LTC5586_ChangeFrequency(float freq);

#endif /* SRC_LTC5596_SPI_H_ */
