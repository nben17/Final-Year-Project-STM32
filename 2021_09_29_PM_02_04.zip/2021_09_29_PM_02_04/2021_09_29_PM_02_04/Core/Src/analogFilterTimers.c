/*
 * analogFilterTimers.c
 *
 *  Created on: Oct 2, 2021
 *      Author: JerryBenny
 */

#include "stm32f4xx_hal.h"
#include "math.h"

//This function takes parameters for the filter timers' frequency and drives the filter timers at the frequency required to maintain that cutoff frequency.
//For example, if freqNum = 10 and freqMag = 1, this function will update the appropriate timer to drive a square wave at 10*100 Hz, which will in turn cause the lowpass filter's cutoff frequency to be set at 10 Hz.
  void updateTimerParams(TIM_HandleTypeDef timerInstance, uint8_t channel, uint8_t * freqNum, uint8_t * freqMag, uint16_t * prescalerRef, uint32_t * ARR_ref, uint32_t * CCRx_ref){
	  //This function takes a filter cutoff frequency in the form (filterFreqNum x 10^filterFreqMag) Hz, and sets the parameters of the timer referred to by timerInstance to achieve that filter cutoff frequency.
	  //For example, if we would like the filter cutoff at 100 Hz, this function should be passed filterFreqNum = 100, filterFreqMag = 0 (100*10^0 = 100 Hz)
	  *prescalerRef = 7 * pow(10, 3 - *freqMag) - 1; //The minus 1 is necessary for the square wave to be generated as intended due to STM32 characteristics.
	  *ARR_ref = 240 / *freqNum - 1; //The minus 1 is necessary for the square wave to be generated as intended due to STM32 characteristics.
	  //Adjusting the CCR value to be half the value of ARR in order to maintain 50% duty cycle
	  *CCRx_ref = 120 / *freqNum;
	  //Adjusting the prescaler value sets the frequency of output waveforms
	  timerInstance.Instance->PSC = *prescalerRef;
	  //ARR is set to the value calculated above.
	  timerInstance.Instance->ARR = *ARR_ref;
	  if (channel == 1){
		  //Depending on the channel that the user choses adjust the appropriate CCR register eg CCR1 for channel 1 etc.
		  timerInstance.Instance->CCR1 = *CCRx_ref;
	  }else if (channel == 4){
		  timerInstance.Instance->CCR4 = *CCRx_ref;
	  }
  }

