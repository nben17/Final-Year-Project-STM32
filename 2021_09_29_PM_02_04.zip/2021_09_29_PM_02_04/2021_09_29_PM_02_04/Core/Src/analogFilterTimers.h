/*
 * analogFilterTimers.h
 *
 *  Created on: Oct 2, 2021
 *      Author: JerryBenny
 */

#ifndef SRC_ANALOGFILTERTIMERS_H_
	//Include the header file if not defined
	#define SRC_ANALOGFILTERTIMERS_H_

	//Dependencies
	#include "math.h"
	#include "stm32f4xx_hal.h"

	//Definitions
	#define RX_TIMER_CHANNEL 1
	#define TX_TIMER_CHANNEL 4

	//Variables
	uint8_t rxFilterFreqNum = 1;
	uint8_t rxFilterFreqMag = 2; //The filter frequency magnitude and number variables combine to give a default cutoff frequency of 1 kHz
	uint16_t rxFilterPrescalerRef = 16800 - 1; //Divides the clock by 16800 (so the timer counts up every 1/10000th of a second)
	uint32_t rxFilterARR_ref = 100 - 1; //This variable and CCRX_ref are the ones that need to be changed to give variable frequency. This variable tells the counter at which count value it should reset its count to 0. 100 - 1 (99) means that the counter will reset every 100 counts and so on.
	uint32_t rxFilterCCRx_ref = 50; //Needs to be half of ARR
	uint8_t txFilterFreqNum = 1;
	uint8_t txFilterFreqMag = 3; //The filter frequency magnitude and number variables combine to give a default cutoff frequency of 1 kHz
	uint16_t txFilterPrescalerRef = 16800 - 1; //Divides the clock by 16800 (so the timer counts up every 1/10000th of a second)
	uint32_t txFilterARR_ref = 100 - 1; //This variable and CCRX_ref are the ones that need to be changed to give variable frequency. This variable tells the counter at which count value it should reset its count to 0. 100 - 1 (99) means that the counter will reset every 100 counts and so on.
	uint32_t txFilterCCRx_ref = 50; //Needs to be half of ARR

	//Function Declarations
	void updateTimerParams(TIM_HandleTypeDef timerInstance, uint8_t channel, uint8_t * freqNum, uint8_t * freqMag, uint16_t * prescalerRef, uint32_t * ARR_ref, uint32_t * CCRx_ref);

#endif /* SRC_ANALOGFILTERTIMERS_H_ */
