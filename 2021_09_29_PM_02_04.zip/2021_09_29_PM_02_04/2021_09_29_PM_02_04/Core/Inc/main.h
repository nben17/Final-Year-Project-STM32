/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

void HAL_TIM_MspPostInit(TIM_HandleTypeDef *htim);

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define TEST_INPUT_PIN_Pin GPIO_PIN_7
#define TEST_INPUT_PIN_GPIO_Port GPIOA
#define TEST_OUTPUT_PIN_Pin GPIO_PIN_4
#define TEST_OUTPUT_PIN_GPIO_Port GPIOC
#define ADL5375_RF_Disable_Pin GPIO_PIN_0
#define ADL5375_RF_Disable_GPIO_Port GPIOB
#define LTC5586_TEMP_Pin GPIO_PIN_12
#define LTC5586_TEMP_GPIO_Port GPIOB
#define LTC5586_CSB_Pin GPIO_PIN_13
#define LTC5586_CSB_GPIO_Port GPIOB
#define LTC5586_RF_Sel_Pin GPIO_PIN_14
#define LTC5586_RF_Sel_GPIO_Port GPIOB
#define LTC5586_VCM_Pin GPIO_PIN_15
#define LTC5586_VCM_GPIO_Port GPIOB
#define DAC_TEST_PIN_Pin GPIO_PIN_6
#define DAC_TEST_PIN_GPIO_Port GPIOC
#define ADC_TEST_PIN_Pin GPIO_PIN_7
#define ADC_TEST_PIN_GPIO_Port GPIOC
#define ADF4351_SCK_Pin GPIO_PIN_10
#define ADF4351_SCK_GPIO_Port GPIOC
#define ADF4351_MOSI_Pin GPIO_PIN_12
#define ADF4351_MOSI_GPIO_Port GPIOC
#define LTC5586_SCK_Pin GPIO_PIN_3
#define LTC5586_SCK_GPIO_Port GPIOB
#define LTC5586_MOSI_Pin GPIO_PIN_4
#define LTC5586_MOSI_GPIO_Port GPIOB
#define LTC5586_MISO_Pin GPIO_PIN_5
#define LTC5586_MISO_GPIO_Port GPIOB
#define ADF4351_MUXOUT_Pin GPIO_PIN_6
#define ADF4351_MUXOUT_GPIO_Port GPIOB
#define ADF4351_CE_Pin GPIO_PIN_7
#define ADF4351_CE_GPIO_Port GPIOB
#define ADF4351_RF_PwrDwn_Pin GPIO_PIN_8
#define ADF4351_RF_PwrDwn_GPIO_Port GPIOB
#define ADF4351_LE_Pin GPIO_PIN_9
#define ADF4351_LE_GPIO_Port GPIOB
/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
